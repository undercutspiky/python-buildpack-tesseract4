"""For development purposes, support invocation of pythonz with python -m."""

import pythonz
pythonz.main()
